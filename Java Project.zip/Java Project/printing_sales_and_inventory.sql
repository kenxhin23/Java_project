-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2018 at 08:23 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `printing_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `cust_detail`
--

CREATE TABLE `cust_detail` (
  `cust_id` int(1) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `phone_no` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cust_detail`
--

INSERT INTO `cust_detail` (`cust_id`, `cname`, `phone_no`) VALUES
(1, 'ken', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `item_no` int(1) NOT NULL,
  `items` varchar(50) NOT NULL,
  `no_roll` varchar(50) NOT NULL,
  `paper_type` varchar(50) NOT NULL,
  `no_of_prints` int(50) NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`item_no`, `items`, `no_roll`, `paper_type`, `no_of_prints`, `price`) VALUES
(20, '3r', '1', 'GLOSSY', 1000, '5'),
(21, '3r', '1', 'MATTE', 1000, '5'),
(22, '4r', '1', 'GLOSSY', 1000, '6'),
(23, '4r', '1', 'MATTE', 1000, '6'),
(24, '5r', '1', 'MATTE', 600, '15'),
(25, '6r', '2', 'MATTE', 800, '20'),
(26, '8r', '1', 'MATTE', 200, '35'),
(27, '8x12', '1', 'MATTE', 160, '45'),
(28, '12x14', '1', 'SILK', 100, '80'),
(29, 'Photo Album', '0', 'Others', 0, '400'),
(30, '2x2', '0', 'Others', 0, '60');

-- --------------------------------------------------------

--
-- Table structure for table `purchasing`
--

CREATE TABLE `purchasing` (
  `order_no` int(1) NOT NULL,
  `cust_id` int(1) NOT NULL,
  `item_no` int(1) NOT NULL,
  `items` varchar(50) NOT NULL,
  `paper_type` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `or_quantity` int(50) NOT NULL,
  `error` varchar(50) NOT NULL,
  `t_amount` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `month` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchasing`
--

INSERT INTO `purchasing` (`order_no`, `cust_id`, `item_no`, `items`, `paper_type`, `price`, `or_quantity`, `error`, `t_amount`, `date`, `month`) VALUES
(23, 1, 19, '5r', 'MATTE', '15', 7, '0', '105.0', ' 2018/07/27  12:07', 'March');

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `id` int(1) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`id`, `firstname`, `lastname`, `username`, `password`, `type`) VALUES
(1, 'Kenshin', 'Himura', 'kenxhin', '1234', 'Admin'),
(2, 'Anya', 'Murray', 'anya', '4321', 'Cashier'),
(3, 'ako', 'siya', 'akosiya', '12345', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cust_detail`
--
ALTER TABLE `cust_detail`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`item_no`);

--
-- Indexes for table `purchasing`
--
ALTER TABLE `purchasing`
  ADD PRIMARY KEY (`order_no`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cust_detail`
--
ALTER TABLE `cust_detail`
  MODIFY `cust_id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `item_no` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `purchasing`
--
ALTER TABLE `purchasing`
  MODIFY `order_no` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `user_account`
--
ALTER TABLE `user_account`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
